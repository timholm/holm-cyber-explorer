package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/fsnotify/fsnotify"
	"github.com/gorilla/websocket"
)

var (
	requestCount uint64
	startTime    = time.Now()
)

const dataPath = "/data"

var upgrader = websocket.Upgrader{
	ReadBufferSize:  1024,
	WriteBufferSize: 1024,
	CheckOrigin: func(r *http.Request) bool {
		return true
	},
}

type WatchEvent struct {
	Type      string    `json:"type"`      // create, write, remove, rename, chmod
	Path      string    `json:"path"`
	Timestamp time.Time `json:"timestamp"`
}

type WatchRequest struct {
	Path      string `json:"path"`
	Recursive bool   `json:"recursive"`
}

type HealthResponse struct {
	Status    string `json:"status"`
	Service   string `json:"service"`
	Timestamp string `json:"timestamp"`
}

type MetricsResponse struct {
	Uptime          string `json:"uptime"`
	Requests        uint64 `json:"requests"`
	ActiveWatchers  int    `json:"active_watchers"`
	Service         string `json:"service"`
}

type WatchManager struct {
	watchers map[*websocket.Conn]*fsnotify.Watcher
	mu       sync.Mutex
}

var watchManager = &WatchManager{
	watchers: make(map[*websocket.Conn]*fsnotify.Watcher),
}

func (wm *WatchManager) Add(conn *websocket.Conn, watcher *fsnotify.Watcher) {
	wm.mu.Lock()
	defer wm.mu.Unlock()
	wm.watchers[conn] = watcher
}

func (wm *WatchManager) Remove(conn *websocket.Conn) {
	wm.mu.Lock()
	defer wm.mu.Unlock()
	if watcher, ok := wm.watchers[conn]; ok {
		watcher.Close()
		delete(wm.watchers, conn)
	}
}

func (wm *WatchManager) Count() int {
	wm.mu.Lock()
	defer wm.mu.Unlock()
	return len(wm.watchers)
}

func addRecursiveWatch(watcher *fsnotify.Watcher, root string) error {
	return filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return nil // Skip errors
		}
		if info.IsDir() {
			return watcher.Add(path)
		}
		return nil
	})
}

func eventTypeString(op fsnotify.Op) string {
	switch {
	case op&fsnotify.Create == fsnotify.Create:
		return "create"
	case op&fsnotify.Write == fsnotify.Write:
		return "write"
	case op&fsnotify.Remove == fsnotify.Remove:
		return "remove"
	case op&fsnotify.Rename == fsnotify.Rename:
		return "rename"
	case op&fsnotify.Chmod == fsnotify.Chmod:
		return "chmod"
	default:
		return "unknown"
	}
}

func watchHandler(w http.ResponseWriter, r *http.Request) {
	atomic.AddUint64(&requestCount, 1)

	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		log.Printf("WebSocket upgrade error: %v", err)
		return
	}
	defer conn.Close()

	// Read watch request
	_, message, err := conn.ReadMessage()
	if err != nil {
		log.Printf("Read error: %v", err)
		return
	}

	var req WatchRequest
	if err := json.Unmarshal(message, &req); err != nil {
		conn.WriteJSON(map[string]string{"error": "Invalid JSON: " + err.Error()})
		return
	}

	if req.Path == "" {
		conn.WriteJSON(map[string]string{"error": "Path is required"})
		return
	}

	// Sanitize path
	cleanPath := filepath.Clean(req.Path)
	if strings.Contains(cleanPath, "..") {
		conn.WriteJSON(map[string]string{"error": "Invalid path"})
		return
	}

	fullPath := filepath.Join(dataPath, cleanPath)

	// Verify path exists
	if _, err := os.Stat(fullPath); err != nil {
		conn.WriteJSON(map[string]string{"error": "Path not found: " + err.Error()})
		return
	}

	// Create watcher
	watcher, err := fsnotify.NewWatcher()
	if err != nil {
		conn.WriteJSON(map[string]string{"error": "Failed to create watcher: " + err.Error()})
		return
	}

	watchManager.Add(conn, watcher)
	defer watchManager.Remove(conn)

	// Add path(s) to watcher
	if req.Recursive {
		if err := addRecursiveWatch(watcher, fullPath); err != nil {
			conn.WriteJSON(map[string]string{"error": "Failed to add recursive watch: " + err.Error()})
			return
		}
	} else {
		if err := watcher.Add(fullPath); err != nil {
			conn.WriteJSON(map[string]string{"error": "Failed to add watch: " + err.Error()})
			return
		}
	}

	// Send confirmation
	conn.WriteJSON(map[string]interface{}{
		"status":    "watching",
		"path":      req.Path,
		"recursive": req.Recursive,
	})

	// Handle events
	done := make(chan struct{})

	go func() {
		defer close(done)
		for {
			_, _, err := conn.ReadMessage()
			if err != nil {
				return
			}
		}
	}()

	for {
		select {
		case event, ok := <-watcher.Events:
			if !ok {
				return
			}

			// Get relative path
			relPath, _ := filepath.Rel(dataPath, event.Name)

			watchEvent := WatchEvent{
				Type:      eventTypeString(event.Op),
				Path:      relPath,
				Timestamp: time.Now(),
			}

			if err := conn.WriteJSON(watchEvent); err != nil {
				log.Printf("Write error: %v", err)
				return
			}

			// If a new directory is created and recursive is enabled, watch it
			if req.Recursive && event.Op&fsnotify.Create == fsnotify.Create {
				if info, err := os.Stat(event.Name); err == nil && info.IsDir() {
					watcher.Add(event.Name)
				}
			}

		case err, ok := <-watcher.Errors:
			if !ok {
				return
			}
			conn.WriteJSON(map[string]string{"error": err.Error()})

		case <-done:
			return
		}
	}
}

func healthHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(HealthResponse{
		Status:    "healthy",
		Service:   "file-watch",
		Timestamp: time.Now().UTC().Format(time.RFC3339),
	})
}

func metricsHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(MetricsResponse{
		Uptime:         time.Since(startTime).String(),
		Requests:       atomic.LoadUint64(&requestCount),
		ActiveWatchers: watchManager.Count(),
		Service:        "file-watch",
	})
}

func main() {
	if err := os.MkdirAll(dataPath, 0755); err != nil {
		log.Printf("Warning: Could not create data directory: %v", err)
	}

	http.HandleFunc("/watch", watchHandler)
	http.HandleFunc("/health", healthHandler)
	http.HandleFunc("/metrics", metricsHandler)

	fmt.Println("file-watch service starting on :8080")
	log.Fatal(http.ListenAndServe(":8080", nil))
}
