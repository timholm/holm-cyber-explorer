package main

import (
	"archive/zip"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync/atomic"
	"time"
)

var (
	requestCount uint64
	startTime    = time.Now()
)

const dataPath = "/data"

type DecompressRequest struct {
	Path       string `json:"path"`        // Zip file path
	OutputPath string `json:"output_path"` // Destination folder
}

type DecompressResponse struct {
	OutputPath     string   `json:"output_path,omitempty"`
	FilesExtracted int      `json:"files_extracted,omitempty"`
	TotalSize      int64    `json:"total_size,omitempty"`
	Files          []string `json:"files,omitempty"`
	Error          string   `json:"error,omitempty"`
}

type HealthResponse struct {
	Status    string `json:"status"`
	Service   string `json:"service"`
	Timestamp string `json:"timestamp"`
}

type MetricsResponse struct {
	Uptime   string `json:"uptime"`
	Requests uint64 `json:"requests"`
	Service  string `json:"service"`
}

func extractFile(f *zip.File, destDir string) (int64, error) {
	// Check for zip slip vulnerability
	destPath := filepath.Join(destDir, f.Name)
	if !strings.HasPrefix(filepath.Clean(destPath), filepath.Clean(destDir)+string(os.PathSeparator)) {
		return 0, fmt.Errorf("illegal file path: %s", f.Name)
	}

	if f.FileInfo().IsDir() {
		return 0, os.MkdirAll(destPath, 0755)
	}

	// Create directory structure
	if err := os.MkdirAll(filepath.Dir(destPath), 0755); err != nil {
		return 0, err
	}

	// Extract file
	srcFile, err := f.Open()
	if err != nil {
		return 0, err
	}
	defer srcFile.Close()

	destFile, err := os.OpenFile(destPath, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, f.Mode())
	if err != nil {
		return 0, err
	}
	defer destFile.Close()

	written, err := io.Copy(destFile, srcFile)
	return written, err
}

func decompressHandler(w http.ResponseWriter, r *http.Request) {
	atomic.AddUint64(&requestCount, 1)
	w.Header().Set("Content-Type", "application/json")

	if r.Method != http.MethodPost {
		json.NewEncoder(w).Encode(DecompressResponse{Error: "Method not allowed"})
		return
	}

	var req DecompressRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(DecompressResponse{Error: "Invalid JSON: " + err.Error()})
		return
	}

	if req.Path == "" {
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(DecompressResponse{Error: "Path is required"})
		return
	}

	if req.OutputPath == "" {
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(DecompressResponse{Error: "Output path is required"})
		return
	}

	// Sanitize paths
	cleanPath := filepath.Clean(req.Path)
	cleanOutput := filepath.Clean(req.OutputPath)
	if strings.Contains(cleanPath, "..") || strings.Contains(cleanOutput, "..") {
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(DecompressResponse{Error: "Invalid path"})
		return
	}

	zipFullPath := filepath.Join(dataPath, cleanPath)
	outputFullPath := filepath.Join(dataPath, cleanOutput)

	// Open zip file
	reader, err := zip.OpenReader(zipFullPath)
	if err != nil {
		w.WriteHeader(http.StatusNotFound)
		json.NewEncoder(w).Encode(DecompressResponse{Error: "Failed to open zip file: " + err.Error()})
		return
	}
	defer reader.Close()

	// Create output directory
	if err := os.MkdirAll(outputFullPath, 0755); err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		json.NewEncoder(w).Encode(DecompressResponse{Error: "Failed to create output directory: " + err.Error()})
		return
	}

	var filesExtracted int
	var totalSize int64
	var fileList []string

	for _, f := range reader.File {
		size, err := extractFile(f, outputFullPath)
		if err != nil {
			w.WriteHeader(http.StatusInternalServerError)
			json.NewEncoder(w).Encode(DecompressResponse{Error: "Failed to extract file: " + err.Error()})
			return
		}

		if !f.FileInfo().IsDir() {
			filesExtracted++
			totalSize += size
			fileList = append(fileList, f.Name)
		}
	}

	json.NewEncoder(w).Encode(DecompressResponse{
		OutputPath:     req.OutputPath,
		FilesExtracted: filesExtracted,
		TotalSize:      totalSize,
		Files:          fileList,
	})
}

func healthHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(HealthResponse{
		Status:    "healthy",
		Service:   "file-decompress",
		Timestamp: time.Now().UTC().Format(time.RFC3339),
	})
}

func metricsHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(MetricsResponse{
		Uptime:   time.Since(startTime).String(),
		Requests: atomic.LoadUint64(&requestCount),
		Service:  "file-decompress",
	})
}

func main() {
	if err := os.MkdirAll(dataPath, 0755); err != nil {
		log.Printf("Warning: Could not create data directory: %v", err)
	}

	http.HandleFunc("/decompress", decompressHandler)
	http.HandleFunc("/health", healthHandler)
	http.HandleFunc("/metrics", metricsHandler)

	fmt.Println("file-decompress service starting on :8080")
	log.Fatal(http.ListenAndServe(":8080", nil))
}
