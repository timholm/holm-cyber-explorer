package main

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"image"
	"image/gif"
	"image/jpeg"
	"image/png"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync/atomic"
	"time"

	"golang.org/x/image/draw"
)

var (
	requestCount uint64
	startTime    = time.Now()
)

const dataPath = "/data"

type ThumbnailRequest struct {
	Path   string `json:"path"`
	Width  int    `json:"width"`
	Height int    `json:"height"`
	Format string `json:"format,omitempty"` // jpeg, png (default: jpeg)
}

type ThumbnailResponse struct {
	Path     string `json:"path"`
	Width    int    `json:"width"`
	Height   int    `json:"height"`
	Base64   string `json:"base64,omitempty"`
	MimeType string `json:"mime_type,omitempty"`
	Error    string `json:"error,omitempty"`
}

type HealthResponse struct {
	Status    string `json:"status"`
	Service   string `json:"service"`
	Timestamp string `json:"timestamp"`
}

type MetricsResponse struct {
	Uptime   string `json:"uptime"`
	Requests uint64 `json:"requests"`
	Service  string `json:"service"`
}

func resizeImage(src image.Image, width, height int) image.Image {
	srcBounds := src.Bounds()
	srcWidth := srcBounds.Dx()
	srcHeight := srcBounds.Dy()

	// Calculate aspect ratio
	if width == 0 && height == 0 {
		width = 150
		height = 150
	} else if width == 0 {
		width = int(float64(height) * float64(srcWidth) / float64(srcHeight))
	} else if height == 0 {
		height = int(float64(width) * float64(srcHeight) / float64(srcWidth))
	}

	// Maintain aspect ratio - fit within bounds
	srcRatio := float64(srcWidth) / float64(srcHeight)
	dstRatio := float64(width) / float64(height)

	var newWidth, newHeight int
	if srcRatio > dstRatio {
		newWidth = width
		newHeight = int(float64(width) / srcRatio)
	} else {
		newHeight = height
		newWidth = int(float64(height) * srcRatio)
	}

	dst := image.NewRGBA(image.Rect(0, 0, newWidth, newHeight))
	draw.CatmullRom.Scale(dst, dst.Bounds(), src, srcBounds, draw.Over, nil)

	return dst
}

func thumbnailHandler(w http.ResponseWriter, r *http.Request) {
	atomic.AddUint64(&requestCount, 1)
	w.Header().Set("Content-Type", "application/json")

	if r.Method != http.MethodPost {
		json.NewEncoder(w).Encode(ThumbnailResponse{Error: "Method not allowed"})
		return
	}

	var req ThumbnailRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(ThumbnailResponse{Error: "Invalid JSON: " + err.Error()})
		return
	}

	if req.Path == "" {
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(ThumbnailResponse{Error: "Path is required"})
		return
	}

	// Sanitize path
	cleanPath := filepath.Clean(req.Path)
	if strings.Contains(cleanPath, "..") {
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(ThumbnailResponse{Error: "Invalid path"})
		return
	}

	fullPath := filepath.Join(dataPath, cleanPath)

	// Check file extension
	ext := strings.ToLower(filepath.Ext(fullPath))
	supportedFormats := map[string]bool{
		".jpg": true, ".jpeg": true, ".png": true, ".gif": true,
	}
	if !supportedFormats[ext] {
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(ThumbnailResponse{Error: "Unsupported image format"})
		return
	}

	file, err := os.Open(fullPath)
	if err != nil {
		w.WriteHeader(http.StatusNotFound)
		json.NewEncoder(w).Encode(ThumbnailResponse{Error: "File not found: " + err.Error()})
		return
	}
	defer file.Close()

	// Decode image
	var img image.Image
	switch ext {
	case ".jpg", ".jpeg":
		img, err = jpeg.Decode(file)
	case ".png":
		img, err = png.Decode(file)
	case ".gif":
		img, err = gif.Decode(file)
	}

	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		json.NewEncoder(w).Encode(ThumbnailResponse{Error: "Failed to decode image: " + err.Error()})
		return
	}

	// Set defaults
	if req.Width == 0 {
		req.Width = 150
	}
	if req.Height == 0 {
		req.Height = 150
	}
	if req.Format == "" {
		req.Format = "jpeg"
	}

	// Resize
	thumbnail := resizeImage(img, req.Width, req.Height)

	// Encode to buffer
	var buf bytes.Buffer
	var mimeType string

	switch req.Format {
	case "png":
		err = png.Encode(&buf, thumbnail)
		mimeType = "image/png"
	default:
		err = jpeg.Encode(&buf, thumbnail, &jpeg.Options{Quality: 85})
		mimeType = "image/jpeg"
	}

	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		json.NewEncoder(w).Encode(ThumbnailResponse{Error: "Failed to encode thumbnail: " + err.Error()})
		return
	}

	bounds := thumbnail.Bounds()
	json.NewEncoder(w).Encode(ThumbnailResponse{
		Path:     req.Path,
		Width:    bounds.Dx(),
		Height:   bounds.Dy(),
		Base64:   base64.StdEncoding.EncodeToString(buf.Bytes()),
		MimeType: mimeType,
	})
}

func healthHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(HealthResponse{
		Status:    "healthy",
		Service:   "file-thumbnail",
		Timestamp: time.Now().UTC().Format(time.RFC3339),
	})
}

func metricsHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(MetricsResponse{
		Uptime:   time.Since(startTime).String(),
		Requests: atomic.LoadUint64(&requestCount),
		Service:  "file-thumbnail",
	})
}

func main() {
	if err := os.MkdirAll(dataPath, 0755); err != nil {
		log.Printf("Warning: Could not create data directory: %v", err)
	}

	http.HandleFunc("/thumbnail", thumbnailHandler)
	http.HandleFunc("/health", healthHandler)
	http.HandleFunc("/metrics", metricsHandler)

	fmt.Println("file-thumbnail service starting on :8080")
	log.Fatal(http.ListenAndServe(":8080", nil))
}
